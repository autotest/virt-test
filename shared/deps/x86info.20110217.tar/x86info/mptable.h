#ifndef _MPTABLE_H
#define _MPTABLE_H

#define	SMP_NO	0
#define SMP_YES	1

int issmp(int verbose);

#endif
